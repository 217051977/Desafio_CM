package pt.ulusofona.cm.kotlin.challenge.exceptions

import java.lang.Exception

class AlterarPosicaoException(message: String) : Exception(message) {
    init {
        printStackTrace()
    }
}