package pt.ulusofona.cm.kotlin.challenge.exceptions

import java.lang.Exception

class MenorDeIdadeException(message: String) : Exception(message) {
    init {
        printStackTrace()
    }
}