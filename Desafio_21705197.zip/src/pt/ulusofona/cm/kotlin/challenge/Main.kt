package pt.ulusofona.cm.kotlin.challenge

fun main() {
    
}