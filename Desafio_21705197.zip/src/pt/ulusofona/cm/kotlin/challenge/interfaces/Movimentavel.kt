package pt.ulusofona.cm.kotlin.challenge.interfaces

interface Movimentavel {

    fun moverPara(x: Int, y: Int)

}