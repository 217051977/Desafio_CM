package pt.ulusofona.cm.kotlin.challenge.interfaces

interface Ligavel {

    fun ligar()

    fun desligar()

    fun estaLigado(): Boolean

}