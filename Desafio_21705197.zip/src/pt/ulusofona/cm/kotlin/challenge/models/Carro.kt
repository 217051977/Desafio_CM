package pt.ulusofona.cm.kotlin.challenge.models

import pt.ulusofona.cm.kotlin.challenge.exceptions.VeiculoDesligadoException

class Carro(identificador: String, val motor: Motor) : Veiculo(identificador) {

    override fun moverPara(x: Int, y: Int) {
        if (motor.estaLigado()) {
            super.moverPara(x, y)
            if (!motor.estaLigado()) {
                motor.ligar()
            }
        } else {
            super.moverPara(x, y)
            if (motor.estaLigado()) {
                motor.desligar()
            }
        }
    }

    override fun equals(other: Carro): Boolean {
        return identificador == other.identificador && motor.equals(motor)
    }

    override fun toString(): String {
        return "${super.toString()} | $motor"
    }

}